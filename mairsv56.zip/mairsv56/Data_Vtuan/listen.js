const moment = require('moment-timezone');
const fs = require('fs-extra');
const path = require('path');

const thoiGianHienTai = moment.tz("Asia/Ho_Chi_MinH");
const gioHienTai = thoiGianHienTai.hour();
const phutHienTai = thoiGianHienTai.minute();
const giayHienTai = thoiGianHienTai.second();

module.exports = function ({ api, models }) {
  const Users = require("./controllers/users")({ models, api });
  const Threads = require("./controllers/threads")({ models, api });
  const Currencies = require("./controllers/currencies")({ models });
  const logger = require("../utils/log.js");

  (async function () {
    try {
      logger(global.getText('listen', 'startLoadEnvironment'), 'DATA');

      const threads = await Threads.getAll();
      const users = await Users.getAll(['userID', 'name', 'data']);
      const currencies = await Currencies.getAll(['userID']);

      threads.forEach(data => {
        const idThread = String(data.threadID);
        global.data.allThreadID.push(idThread);
        global.data.threadData.set(idThread, data.data || {});
        global.data.threadInfo.set(idThread, data.threadInfo || {});

        if (data.data && data.data.banned) {
          global.data.threadBanned.set(idThread, {
            'reason': data.data.reason || '',
            'dateAdded': data.data.dateAdded || ''
          });
        }

        if (data.data && data.data.commandBanned && Array.isArray(data.data.commandBanned) && data.data.commandBanned.length > 0) {
          global.data.commandBanned.set(idThread, data.data.commandBanned);
        }

        if (data.data && data.data.NSFW) {
          global.data.threadAllowNSFW.push(idThread);
        }
      });

      logger.loader(global.getText('listen', 'loadedEnvironmentThread'));

      users.forEach(dataU => {
        const idUsers = String(dataU.userID);
        global.data.allUserID.push(idUsers);

        if (dataU.name && Array.isArray(dataU.name) && dataU.name.length > 0) {
          global.data.userName.set(idUsers, dataU.name);
        }

        if (dataU.data && dataU.data.banned === 1) {
          global.data.userBanned.set(idUsers, {
            'reason': dataU.data.reason || '',
            'dateAdded': dataU.data.dateAdded || ''
          });
        }

        if (dataU.data && dataU.data.commandBanned && Array.isArray(dataU.data.commandBanned) && dataU.data.commandBanned.length > 0) {
          global.data.commandBanned.set(idUsers, dataU.data.commandBanned);
        }
      });

      currencies.forEach(dataC => global.data.allCurrenciesID.push(String(dataC.userID)));
    } catch (error) {
      logger.loader(global.getText('listen', 'failLoadEnvironment', error), 'error');
    }
  })();

  async function GuiTuonTac(api) {
    const lichTrinh = [{ gio: 23, phut: 59, giay: 40 }];

    for (const thoiDiem of lichTrinh) {
      if (gioHienTai === thoiDiem.gio && phutHienTai === thoiDiem.phut && giayHienTai === thoiDiem.giay) {
        const messageCountFolderPath = path.resolve(__dirname, '../modules/commands/cache/data/messageCounts');
        const nhom = await api.getThreadList(100, null, ['INBOX']);
        const threadsInfo = await Promise.all(nhom.map((thread) => api.getThreadInfo(thread.threadID)));
        const filteredThreads = threadsInfo.filter(thread => thread.isGroup && thread.participantIDs.includes(api.getCurrentUserID()));
        const threadIDs = filteredThreads.map(thread => thread.threadID);

        const directoryContent = await fs.readdir(messageCountFolderPath);
        const messageCountFiles = directoryContent.filter((file) => file.endsWith('.json'));
        let groupMessageCounts = [];

        for (const file of messageCountFiles) {
          const filePath = path.join(messageCountFolderPath, file);
          const data = await fs.readJson(filePath);
          const totalMessages = data.reduce((acc, cur) => acc + cur.count, 0);
          groupMessageCounts.push({ threadID: file.replace('.json', ''), totalMessages });
        }

        groupMessageCounts.sort((a, b) => b.totalMessages - a.totalMessages);

        if (moment().day() === 0) {
          let message = '== [ AuTo Checktt ] ==\n';

          for (let ia = 0; ia < groupMessageCounts.length; ia++) {
            const groupInfo = filteredThreads.find(thread => thread.threadID === groupMessageCounts[ia].threadID);
            if (threadIDs.includes(groupMessageCounts[ia].threadID)) {
              try {
                message += `${ia + 1}. ${groupInfo.name}: ${groupMessageCounts[ia].totalMessages} tin nhắn\n`;
              } catch (error) {
                console.error(`Không thể lấy thông tin nhóm với ID ${groupMessageCounts[ia].threadID}`);
                message += `${ia + 1}. Không tên: ${groupMessageCounts[ia].totalMessages} tin nhắn\n`;
              }
            }
          }
          message += `\nXếp hạng tương tác của các nhóm\n`;

          for (let bbb = 0; bbb < threadIDs.length; bbb++) {
            await api.sendMessage(message, threadIDs[bbb]);
          }
        } else {
          for (let ia = 0; ia < groupMessageCounts.length; ia++) {
            const groupID = groupMessageCounts[ia].threadID;
            const Gr = filteredThreads.find(thread => thread.threadID === groupID);

            if (Gr) {
              const filePath = path.join(messageCountFolderPath, `${groupID}.json`);
              const data = await fs.readJson(filePath);

              const userList = [];
              for (let index = 0; index < data.length; index++) {
                const userInfo = data[index];
                const name = userInfo.name || `UserID: ${userInfo.userID}`;
                userList.push({ index: index + 1, userID: userInfo.userID, name, count: userInfo.count });
              }

              const sortedUserList = userList.sort((a, b) => b.count - a.count);

              const top20UserList = sortedUserList.slice(0, 20);

              const ThuTu = top20UserList.map((info, i) => `${i + 1}. ${info.name} (${info.count})`).join('\n');
              const message = `== [ Tương Tác ] ==\n${ThuTu}`;
              await api.sendMessage(message, groupID);
            }
          }
        }
        break;
      }
    }
  }

  async function KiemTraRestart(api) {
    const lichTrinh = [
      { gio: 2, phut: 30, giay: 0 },
      { gio: 11, phut: 30, giay: 0 },
      { gio: 13, phut: 0, giay: 0 },
      { gio: 16, phut: 30, giay: 0 },
      { gio: 19, phut: 30, giay: 0 },
      { gio: 21, phut: 0, giay: 0 },
      { gio: 22, phut: 30, giay: 0 },
      { gio: 23, phut: 40, giay: 0 },
    ];

    for (const thoiDiem of lichTrinh) {
      if (gioHienTai === thoiDiem.gio && phutHienTai === thoiDiem.phut && giayHienTai === thoiDiem.giay) {
        await new Promise(resolve => setTimeout(resolve, 3000));
        process.exit(1);
        break;
      }
    }
  }

  setInterval(() => {
    GuiTuonTac(api);
    KiemTraRestart(api);
  }, 1000);

  
  const admin = config.ADMINBOT;
  logger.loader("┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓");

  for (let i = 0; i < admin.length; i++) {
    const dem = i + 1;
    logger.loader(` ID ADMIN ${dem}: ${(!admin[i]) ? "Trống" : admin[i]}`);
  }

  logger.loader(` ID BOT: ${api.getCurrentUserID()}`);
  logger.loader(` PREFIX: ${!global.config.PREFIX ? "Bạn chưa set prefix" : global.config.PREFIX}`);
  logger.loader(` NAME BOT: ${(!global.config.BOTNAME) ? "This bot was made by Vtuan" : global.config.BOTNAME}`);
  logger.loader("┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛");

  const handleCommand = require("./handle/handleCommand")({ api, models, Users, Threads, Currencies });
  const handleCommandEvent = require("./handle/handleCommandEvent")({ api, models, Users, Threads, Currencies });
  const handleReply = require("./handle/handleReply")({ api, models, Users, Threads, Currencies });
  const handleReaction = require("./handle/handleReaction")({ api, models, Users, Threads, Currencies });
  const handleEvent = require("./handle/handleEvent")({ api, models, Users, Threads, Currencies });
  const handleRefresh = require("./handle/handleRefresh")({ api, models, Users, Threads, Currencies });
  const handleCreateDatabase = require("./handle/handleCreateDatabase")({ api, Threads, Users, Currencies, models });

  logger.loader(`Ping load toàn bộ commands và events • ${Date.now() - global.client.timeStart}ms •`);

  return async (event) => {
    const fs = require('fs-extra');
    const path = require('path');
    const antiImagePath = path.resolve(__dirname, '../modules/commands/cache/data/antiImages/antiImage.json');
    const dataimg = fs.readJsonSync(antiImagePath);
    const request = require('request');

    if (event.type === "change_thread_image") {
      const threadData = dataimg.find(item => item.id === event.threadID.toString());

      if (threadData && threadData.status) {
        const imageFilePath = path.resolve(__dirname, '../modules/commands/cache/data/antiImages', `${event.threadID}.jpg`);
        const changeGroupImage = async () => {
          return new Promise((resolve) => {
            api.changeGroupImage(fs.createReadStream(imageFilePath), event.threadID, () => {
              api.sendMessage(`Anti ảnh nhóm đang được bật, bạn hãy dùng ${global.config.PREFIX}antiimagebox off để tắt<3`, event.threadID, resolve);
            });
          });
        };

        await changeGroupImage();
      } else {
        api.sendMessage(`${event.snippet}`, event.threadID);
      }
    }

    switch (event.type) {
      case "change_thread_image":
        if (global.config.notiGroup) {
          if (threadData && threadData.status) {
            await changeGroupImage();
          } else {
            const msg = '[ CẬP NHẬT NHÓM ]\n' + event.snippet.replace('Bạn', global.config.BOTNAME);
            await api.sendMessage({ body: `${msg}` }, event.threadID);
          }
        }
        break;

      case "message":
      case "message_reply":
      case "message_unsend":
        handleCreateDatabase({ event });
        handleCommand({ event });
        handleReply({ event });
        handleCommandEvent({ event });
        break;

      case "event":
        handleEvent({ event });
        handleRefresh({ event });
        break;

      case "message_reaction":
        const iconUnsendPath = path.join(__dirname, '../modules/commands/cache/data/iconUnsend.json');
        const { iconUnsend } = global.config;

        if (fs.existsSync(iconUnsendPath)) {
          const fileData = fs.readFileSync(iconUnsendPath, 'utf-8');
          const data = JSON.parse(fileData);
          const groupID = event.threadID;
          const groupData = data.find(item => item.groupId === groupID);

          if (groupData && groupData.iconUnsend) {
            if (event.senderID === api.getCurrentUserID() && event.reaction === groupData.iconUnsend) {
              api.unsendMessage(event.messageID);
            }
          } else if (iconUnsend && iconUnsend.status && iconUnsend.icon) {
            if (event.senderID === api.getCurrentUserID() && event.reaction === iconUnsend.icon) {
              api.unsendMessage(event.messageID);
            }
          }
        }

        handleReaction({ event });
        break;

      default:
        break;
    }
  };
};
