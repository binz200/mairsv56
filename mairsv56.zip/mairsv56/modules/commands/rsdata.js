module.exports.config = {
  name: 'rsdata',
  version: '1.0.0',
  credits: 'Vtuan',
  hasPermssion: 1,
  description: 'Xóa dữ liệu của nhóm đang sử dụng',
  commandCategory: 'Quản Trị Viên',
  usages: '...',
  cooldowns: 0
};

const fs = require('fs-extra');
const path = require('path');

module.exports.run = async ({ api, event, args }) => {
  const threadDataPath = path.join(__dirname, `/cache/data/messageCounts/${event.threadID}.json`);
  try {
    await fs.unlink(threadDataPath);
    api.sendMessage('[ ✓ ]→ Đã cập nhật dữ liệu checktt của nhóm về 0', event.threadID);
  } catch (error) {
    console.error('Error deleting thread data:', error);
    api.sendMessage(`Xảy ra lỗi khi cập nhật dữ liệu của nhóm`, event.threadID);
  }
};