const fs = require('fs-extra');
const path = require('path');
const messageCountFolderPath = path.join(__dirname, '../../modules/commands/cache/data/messageCounts');

module.exports.config = {
  name: "topbox",
  version: "1.0.0",
  hasPermission: 0,
  credits: "Vtuan",
  description: "Hiển thị thứ hạng tin nhắn của nhóm",
  commandCategory: "Nhóm",
  usages: "topbox",
  cooldowns: 5
};

module.exports.run = async ({ api, event, args }) => {
  const currentThreadID = event.threadID;
  const directoryContent = await fs.readdir(messageCountFolderPath);
  const messageCountFiles = directoryContent.filter((file) => file.endsWith('.json'));
  let groupMessageCounts = [];
  for (const file of messageCountFiles) {
    const filePath = path.join(messageCountFolderPath, file);
    const data = await fs.readJson(filePath);
    const totalMessages = data.reduce((acc, cur) => acc + cur.count, 0);
    groupMessageCounts.push({ threadID: file.replace('.json', ''), totalMessages });
  }
  groupMessageCounts.sort((a, b) => b.totalMessages - a.totalMessages);

  if (args[0] && args[0].toLowerCase() === 'all') {
    let message = 'Thông tin về các nhóm:\n';
    for (let i = 0; i < groupMessageCounts.length; i++) {
      try {
        const groupInfo = await api.getThreadInfo(groupMessageCounts[i].threadID);
        message += `${i + 1}. Nhóm: ${groupInfo.name} - Số tin nhắn: ${groupMessageCounts[i].totalMessages}\n`;
      } catch (error) {
        console.error(`Không thể lấy thông tin nhóm với ID ${groupMessageCounts[i].threadID}`);
        message += `${i + 1}. Nhóm: Unknown - Số tin nhắn: ${groupMessageCounts[i].totalMessages}\n`;
      }
    }
    api.sendMessage(message, currentThreadID);
  } else {
    try {
      const currentGroupInfo = await api.getThreadInfo(currentThreadID);
      const currentGroupRank = groupMessageCounts.findIndex(group => group.threadID === currentThreadID) + 1;
      const currentGroupMessages = groupMessageCounts.find(group => group.threadID === currentThreadID).totalMessages;
      const totalGroups = groupMessageCounts.length;
      const msg = `Nhóm ${currentGroupInfo.name} có: ${currentGroupMessages} tin nhắn - xếp thứ: ${currentGroupRank} trên ${totalGroups} nhóm\nDùng '!topbox all' để xem xếp hạng các nhóm.`;
      api.sendMessage(msg, currentThreadID);
    } catch (error) {
      console.error(`Không thể lấy thông tin nhóm với ID ${currentThreadID}`);
      api.sendMessage("Không thể lấy thông tin nhóm.", currentThreadID);
    }
  }
};