const fs = require('fs-extra');
const path = require('path');

const messageCountFolderPath = path.join(__dirname, '../../modules/commands/cache/data/messageCounts');

async function createIfNotExist(filePath) {
  if (!(await fs.pathExists(filePath))) {
    await fs.writeJson(filePath, []);
  }
}

module.exports.config = {
  name: "datachecktt",
  version: "1.0.0",
  hasPermssion: 3,
  credits: "Vtuan",
  description: "Tính số lượng tin nhắn của mỗi thành viên.",
  commandCategory: "Hệ Thống",
  usages: "abcxyz",
  cooldowns: 0
};

module.exports.handleEvent = async ({ api, event }) => {
  const threadID = event.threadID;
  const threadFilePath = path.join(messageCountFolderPath, `${threadID}.json`);
  await createIfNotExist(threadFilePath);
  let messageCountData = await fs.readJson(threadFilePath);
  const threadInfo = await api.getThreadInfo(threadID);
  for (const userID of threadInfo.participantIDs) {
    const userExists = messageCountData.some(user => user.userID === userID);
    if (!userExists) {
      const userInfo = await api.getUserInfo(userID);
      const userName = userInfo[userID]?.name || "Unknown";
      messageCountData.push({ userID, count: 0, name: userName });
    }
  }
  const senderID = event.senderID.toString();
  let userMessageData = messageCountData.find(user => user.userID === senderID);
  if (userMessageData) {
    userMessageData.count += 1;
  } else {
    try {
      const userInfo = await api.getUserInfo(senderID);
      userMessageData = {
        userID: senderID,
        count: 1,
        rank: messageCountData.length + 1,
        name: userInfo[senderID]?.name || "Unknown"
      };
      messageCountData.push(userMessageData);
    } catch (error) {
      userMessageData = { userID: senderID, count: 1, rank: messageCountData.length + 1, name: "Unknown"};
      messageCountData.push(userMessageData);
    }
  }
  await fs.writeJson(threadFilePath, messageCountData, { spaces: 2 });
};
module.exports.run = async ({ api, event, args }) => {}
