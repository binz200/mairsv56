module.exports.config = {
  name: "auto",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Vtuan",
  description: "down",
  commandCategory: "Hệ Thống",
  usages: "",
  cooldowns: 5
  };

const axios = require('axios');
const fs = require('fs');
const path = require('path');
const isURL = u => /^http(|s):\/\//.test(u);

const supportedPlatforms = [{ regex: /(^https:\/\/)(\w+\.)?(facebook|fb)\.(com|watch|reel)\/\w+\/\w?(\/)?/ }];

exports.handleEvent = async function(o) {
  try {
    const str = o.event.body;
    const send = msg => o.api.sendMessage(msg, o.event.threadID, o.event.messageID);

    if (isURL(str)) {
       const platform = supportedPlatforms.find(platform => platform.regex.test(str));
       if (platform) {
          const res = await axios.get(`https://thenamk3.net/api/autolink.json?link=${str}&apikey=NemG_4yGSpNyl`);
          const stream = (await axios.get(res.data.videos[0].url, { responseType: "arraybuffer" })).data;

          const filePath = path.join(__dirname, `/cache/fb.mp4`);

          fs.writeFileSync(filePath, Buffer.from(stream, "utf-8"));
          send({ body: `${res.data.videos[0].title}`, attachment: fs.createReadStream(filePath) })
       }
    }
  } catch (e) {
  console.log();
  }
};
module.exports.run = async ({ api, event }) => {}