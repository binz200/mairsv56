const fs = require('fs-extra');
const path = require('path');
const moment = require('moment-timezone');
const messageCountFolderPath = path.join(__dirname, '../../modules/commands/cache/data/messageCounts');

async function createIfNotExist(filePath) {
    if (!(await fs.pathExists(filePath))) {
        await fs.writeJson(filePath, []);
    }
}

async function cleanUpAndFilterMessageCountData(api, threadID, messageCountData) {
    const threadInfo = await api.getThreadInfo(threadID);
    const currentParticipantIDsSet = new Set(threadInfo.participantIDs.map(String));
    return messageCountData.filter(member => currentParticipantIDsSet.has(member.userID));
}

module.exports.config = {
    name: "check",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Vtuan",
    description: "Kiểm tra tương tác",
    commandCategory: "Nhóm",
    usages: "[...|tag|reply|all]",
    cooldowns: 0
};

module.exports.run = async ({ api, event, args }) => {
    var { threadID, messageID, senderID } = event;
    const threadFilePath = path.join(messageCountFolderPath, `${threadID}.json`);
    await createIfNotExist(threadFilePath);
    let messageCountData = await fs.readJson(threadFilePath);
    let totalMessages = messageCountData.reduce((acc, cur) => acc + cur.count, 0);
    let totalUsers = messageCountData.length;
  const { PREFIX } = global.config;
  let threadSetting = global.data.threadData.get(threadID) || {};
  let prefix = threadSetting.PREFIX || PREFIX;
  
    messageCountData.sort((a, b) => b.count - a.count);

    let groupMessageCounts = [];
    const directoryContent = await fs.readdir(messageCountFolderPath);
    for (const file of directoryContent.filter((file) => file.endsWith('.json'))) {
        const filePath = path.join(messageCountFolderPath, file);
        const data = await fs.readJson(filePath);
        const totalMessages = data.reduce((acc, cur) => acc + cur.count, 0);
        groupMessageCounts.push({ threadID: file.replace('.json', ''), totalMessages });
    }
    groupMessageCounts.sort((a, b) => b.totalMessages - a.totalMessages);
    let currentGroupRank = groupMessageCounts.findIndex(group => group.threadID === threadID) + 1;
    let totalGroups = groupMessageCounts.length;
    const threadInfo = await api.getThreadInfo(event.threadID);

    const ic = require('./../../Data_Vtuan/datajson/icon.json');
    var icon = ic[Math.floor(Math.random() * ic.length)].trim();

    let msg = ``;
    let mesenge = ``;
    if (args[0] === 'all') {
        const cleanedMessageCountData = await cleanUpAndFilterMessageCountData(api, threadID, messageCountData);
        const participantIDs = threadInfo.participantIDs.map(participant => participant.toString());
        const filteredMessageCountData = cleanedMessageCountData.filter(userInfo => participantIDs.includes(userInfo.userID));
        const userInformationList = filteredMessageCountData.map((userInfo, index) => {
            const name = userInfo.name || `UserID: ${userInfo.userID}`;
            return { index: index + 1, userID: userInfo.userID, name, count: userInfo.count };
        });
        const userInformationString = userInformationList.map(info => `${info.index}. ${info.name} (${info.count})`).join('\n');
        const resultString = `
== [ Interact Allin ] ==
${userInformationString}

▱▱▱▱▱▱▱▱▱▱▱▱▱
⩥ dùng ${prefix}checkloc để lọc thủ công 
⩥ Dùng ${prefix}lọc + số tin nhắn muốn lọc để lọc thành viên không tương tác
⩥ Dùng ${prefix}rsdata để reset tin nhắn của nhóm về 0
${moment().tz('Asia/Ho_Chi_Minh').format('HH:mm:ss')} || ${moment().tz('Asia/Ho_Chi_Minh').format('DD/MM/YYYY')}
→ Tổng: ${totalMessages} tin nhắn và xếp thứ ${currentGroupRank}/${totalGroups} nhóm.`;
        return api.sendMessage(resultString, threadID, messageID);
    } else {
    let userID;
    if (event.type === 'message_reply') {
      userID = event.messageReply.senderID;
    } else if (Object.keys(event.mentions).length > 0) {
      userID = Object.keys(event.mentions)[0];
    } else {
      userID = args[0] || event.senderID;
    }

    var permission;
    if (global.config.ADMINBOT.includes(userID)) {
      permission = `Admin Bot`;
    } else if (global.config.NDH.includes(userID)) {
      permission = `Người Hỗ Trợ`;
    } else if (threadInfo.adminIDs.some(i => i.id === userID)) {
      permission = `Quản Trị Viên`;
    } else {
      permission = `Thành Viên`;
    }

    const userMessageCountData = messageCountData.find(u => u.userID === userID.toString());
    const userName = userMessageCountData.name || `UserID: ${userID}`;
    const percentageOfInteractions = ((userMessageCountData.count / totalMessages) * 100).toFixed(2);
    const top20PercentThreshold = Math.ceil(totalUsers * 0.2);
    const top60PercentThreshold = Math.ceil(totalUsers * 0.6);
    const userRank = messageCountData.findIndex(user => user.userID === userID.toString()) + 1;
    let tuongTac;
    if (userRank <= top20PercentThreshold) {
      tuongTac = 'tốt';
    } else if (userRank <= top60PercentThreshold) {
      tuongTac = 'bình thường';
    } else {
      tuongTac = 'ít';
    }

    if (userMessageCountData) {
      if (userRank === 1) {
        msg = `\n[ ! ] ‣ Tương tác trong nhóm\n▱▱▱▱▱▱▱▱▱▱▱▱▱\n[${icon}]→ Name: ${userName} \n→ Chức vụ: ${permission} \n→ hiện đang đứng đầu với ${userMessageCountData.count} tin nhắn.\n→ Mức độ tương tác: ${tuongTac}\n→ tỉ lệ tương tác: ${percentageOfInteractions}%\n`;
        if (messageCountData.length > 1) {
          const nextUser = messageCountData[1];
          const nextUserRank = messageCountData.findIndex(user => user.userID === nextUser.userID) + 1;
          msg += `🥈Top 2: ${nextUser.name || `UserID: ${nextUser.userID}`} (${nextUser.count})\n▱▱▱▱▱▱▱▱▱▱▱▱▱`;
        }
      } else {
        const topUser = messageCountData[0];
        const topUserRank = messageCountData.findIndex(user => user.userID === topUser.userID) + 1;
        msg = `[ ! ] ‣ Tương tác trong nhóm\n▱▱▱▱▱▱▱▱▱▱▱▱▱\n[${icon}]→ Name: ${userName}\n→ Chức vụ: ${permission}\n→ Hiện đang đứng thứ ${userRank} với ${userMessageCountData.count} tin nhắn.\n→ Tỉ lệ tương tác: ${percentageOfInteractions}%\n→ Mức độ tương tác: ${tuongTac}\n`;
        msg += `🥇Người dẫn đầu là ${topUser.name || `UserID: ${topUser.userID}`} với ${topUser.count} tin nhắn.\n▱▱▱▱▱▱▱▱▱▱▱▱▱\n`;
      }
    } else {
      msg = `Không tìm thấy số tương tác cho người dùng này.`;
    }
  }
  return api.sendMessage(msg, threadID);
};
