module.exports.config = {
    name: "prefix",	
    version: "4.0.0", 
    hasPermssion: 0,
    credits: "Vtuan",
    description: "sos", 
    commandCategory: "Hệ Thống",
    usages: "",
    cooldowns: 0
  };
  
module.exports.handleEvent = async function ({ api, event, Threads }) {
    const request = require('request');
    const fs = require("fs");
    var { threadID, messageID, body } = event,{ PREFIX } = global.config;
    let threadSetting = global.data.threadData.get(threadID) || {};
    let prefix = threadSetting.PREFIX || PREFIX;
    const timeStart = Date.now();
    if (body.toLowerCase() == "Prefix" || (body.toLowerCase() == "prefix")) {
            return api.sendMessage({
          body: `====『 𝙿𝚁𝙴𝙵𝙸𝚇 』====\n▱▱▱▱▱▱▱▱▱▱▱▱▱\n→𝙿𝚛𝚎𝚏𝚒𝚡 𝚌𝚞̉𝚊 𝚗𝚑𝚘́𝚖: ${prefix}\n→𝙿𝚛𝚎𝚏𝚒𝚡 𝚑𝚎̣̂ 𝚝𝚑𝚘̂́𝚗𝚐: ${global.config.PREFIX}\n→𝚃𝚎̂𝚗 𝚋𝚘𝚝: ${global.config.BOTNAME}\n→𝙱𝚘𝚝 𝚑𝚒𝚎̣̂𝚗 𝚌𝚘́ ${client.commands.size} 𝚕𝚎̣̂𝚗𝚑\n→𝑃𝑖𝑛𝑔: ${Date.now() - timeStart}ms\n▱▱▱▱▱▱▱▱▱▱▱▱▱`},event.threadID,event.messageID);
   }
  }
module.exports.run = async ({ api, event, args, Threads }) => {}
  
  
  