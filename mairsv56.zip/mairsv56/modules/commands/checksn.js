module.exports.config = {
    name: "checksn",
    version: "1.0",
    hasPermission: 0,
    credits: "Vtuan",
    description: "Kiểm tra các thành viên trong nhóm chưa có biệt danh.",
    commandCategory: "Quản Trị Viên",
    usages: "",
    cooldowns: 2,
  };
  
  module.exports.run = async ({ api, event, Users }) => {
    try {
      let threadInfo = await api.getThreadInfo(event.threadID);
      let u = threadInfo.nicknames || {};
      let participantIDs = threadInfo.participantIDs;
      let listbd = participantIDs.filter(userID => !u[userID]);
  
      if (listbd.length > 0) {
        let listNames = [];

        for (let [index, userID] of listbd.entries()) {
          try {
            let userInfo = await Users.getInfo(userID);
            let name = userInfo.name || "Người dùng không có tên";
            listNames.push(`${index + 1}. ${name}`);
          } catch (error) {
            console.error(`Lỗi khi lấy thông tin người dùng có ID: ${userID}`);
          }
        }
        if (listNames.length > 0) {
          api.sendMessage(`Danh sách người chưa có biệt danh:\n${listNames.join("\n")}`, event.threadID);
        } else {
          api.sendMessage(`Không có người nào chưa có biệt danh.`, event.threadID);
        }
      } else {
        api.sendMessage(`Tất cả thành viên đã có biệt danh.`, event.threadID);
      }
    } catch (error) {
      console.error(error);
      api.sendMessage('Đã xảy ra lỗi khi thực hiện chức năng kiểm tra biệt danh.', event.threadID);
    }
  };
  