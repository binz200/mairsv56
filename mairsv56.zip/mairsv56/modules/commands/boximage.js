const fs = require("fs-extra");
const axios = require("axios");

module.exports.config = {
    name: "boximage",
    version: "1.0.2",
    hasPermission: 1,
    credits: "Vtuan",
    description: "",
    commandCategory: "Quản Trị Viên",
    usages: "reply ảnh để đổi",
    cooldowns: 2
};

module.exports.run = async function({ api, event, args }) {
    const { threadID, messageID } = event;

    if (event.type !== "message_reply") return api.sendMessage("➜ Bạn phải reply một ảnh nào đó", threadID, messageID);
    if (!event.messageReply.attachments || event.messageReply.attachments.length === 0) return api.sendMessage("➜ Bạn phải reply một ảnh nào đó", threadID, messageID);
    if (event.messageReply.attachments.length > 1) return api.sendMessage("➜ Bạn chỉ được phép reply một ảnh", threadID, messageID);

    const imageLink = event.messageReply.attachments[0].url;
    const imagePath = __dirname + `/cache/data/antiImages/${threadID}.jpg`;

    const response = await axios({
        method: 'GET',
        url: imageLink,
        responseType: 'stream'
    });

    const writer = fs.createWriteStream(imagePath);
    response.data.pipe(writer);

    writer.on('finish', () => {
        api.changeGroupImage(fs.createReadStream(imagePath), threadID, () => {
        });
    });

    writer.on('error', () => {
        console.log("Có lỗi xảy ra khi tải ảnh");
    });
};
