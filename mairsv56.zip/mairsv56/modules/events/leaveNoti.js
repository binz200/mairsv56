const fs = require('fs-extra');
const path = require('path');
const messageCountFolderPath = path.join(__dirname, '../../modules/commands/cache/data/messageCounts');

module.exports.config = {
  name: "leave",
  eventType: ["log:unsubscribe"],
  version: "1.0.0",
  credits: "Mirai Team",//mod by vtuan
  description: "Thông báo bot hoặc người rời khỏi nhóm",
  dependencies: {
    "fs-extra": "",
    "path": ""
  }
};

module.exports.run = async function ({ api, event, Users, Threads }) {
  const { existsSync, readJson, writeJson } = global.nodemodule["fs-extra"];
  const { threadID, logMessageData } = event;
  const name = global.data.userName.get(logMessageData.leftParticipantFbId) || await Users.getNameUser(logMessageData.leftParticipantFbId);
  const type = (event.author == logMessageData.leftParticipantFbId) ? "rời" : "bị quản trị viên kick";

  let msg = `${name} đã ${type} khỏi nhóm.`;

  const userDataPath = path.join(messageCountFolderPath, `${threadID}.json`);
  if (existsSync(userDataPath)) {
    let messageCountData = await readJson(userDataPath);
    const index = messageCountData.findIndex(data => data.userID === logMessageData.leftParticipantFbId);
    if (index !== -1) {
      messageCountData.splice(index, 1);
    }
    await writeJson(userDataPath, messageCountData, { spaces: 2 });
  }
  return api.sendMessage(msg, threadID);
}
